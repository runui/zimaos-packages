const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const { readFrontendDomain } = require("./frontend-source");

const root = path.resolve(__dirname, "..");

function loadDockingModel() {
  const storage = new Map();
  const noop = () => {};
  const titleCalls = [];
  const sandbox = {
    console,
    Map,
    Set,
    Date,
    Math,
    JSON,
    setTimeout:() => 1,
    clearTimeout:noop,
    CSS:{escape:value => String(value)},
    tabs:[],
    titleCalls,
    activeTabKey:"",
    activeView:"welcome",
    selectedId:null,
    responsiveLayoutMobile:false,
    runtimeSettings:{saved:{restore_workspace_tabs:true}},
    terminalSessions:new Map(),
    sftpDisconnectedTabs:new Set(),
    sftpViewStates:new Map(),
    workspaceTabDrag:null,
    workspaceTabSuppressClickUntil:0,
    window:{restoringTabs:false, addEventListener:noop, removeEventListener:noop},
    document:{
      getElementById:() => null,
      querySelector:() => null,
      querySelectorAll:() => [],
      body:{classList:{add:noop, remove:noop, toggle:noop}, appendChild:noop}
    },
    localStorage:{
      getItem:key => storage.get(key) || null,
      setItem:(key, value) => storage.set(key, String(value))
    },
    requestAnimationFrame:callback => { callback(); return 1; },
    cancelAnimationFrame:noop,
    icon:() => "",
    esc:value => String(value),
    escAttr:value => String(value),
    tr:(key, options={}) => options.defaultValue || key,
    notify:noop,
    hideTabContextMenu:noop,
    closeTerminalSession:noop,
    closeSftpSession:noop,
    stopBatchCommand:noop,
    renderWelcome:noop,
    openTerminal:noop,
    openForwards:noop,
    editConnection:noop,
    showImport:noop,
    openLog:noop,
    openBatchCommand:noop,
    openSftp:noop,
    openServerDashboard:noop,
    openSettings:noop,
    syncTerminalToolbarPlacement:noop,
    syncSftpToolbarPlacement:noop,
    syncWorkspaceDocumentTitle:(...args) => titleCalls.push(args),
    showMobileWorkspace:noop,
    renderTabs:noop,
    updateWorkspaceTabScrollControls:noop,
    scrollWorkspaceTabs:noop,
    handleWorkspaceTabsWheel:noop,
    revealWorkspaceTab:noop,
    addTab:noop,
    setWorkspaceTabConnectionStatus:noop,
    renderTabContent:noop,
    activateTab:noop,
    setWorkspace:noop,
    closeTab:noop,
    closeTabsByKey:noop,
    closeTabsByMode:noop,
    moveWorkspaceTab:noop,
    showTabContextMenu:noop,
    beginWorkspaceTabDrag:noop,
    moveWorkspaceTabDrag:noop,
    finishWorkspaceTabDrag:noop,
    persistableTabs:() => [],
    saveTabsState:noop,
    restoreTabsState:noop,
    syncResponsivePane:noop
  };
  sandbox.selectConnection = id => {
    sandbox.selectedId = id;
    return {id};
  };
  sandbox.openLinuxDesktopManager = (connectionId, updateTab) => {
    sandbox.linuxDesktopManagerOpen = {connectionId, updateTab};
  };
  sandbox.isMobileLayout = () => sandbox.__mobile === true;
  sandbox.globalThis = sandbox;

  const filename = "public/workspace-docking-domain";
  const source = readFrontendDomain(root, "docking")
    .replace(/\r?\nif \(workspaceDockElement\(\)\) \{[\s\S]*?\}\s*else\s*\{[\s\S]*?\}\s*$/, "")
    + `\n;globalThis.__dockingModel = {
      workspaceLeaves,
      workspaceFindPane,
      workspaceFindSplit,
      workspaceReplacePaneWithSplit,
      pruneWorkspaceLayout,
      workspaceFilterLayout,
      workspaceAllTabs,
      workspaceTabByKey,
      workspaceHasTabKey,
      serializeWorkspaceLayout,
      workspaceGroupPersistableTab,
      restoreWorkspaceGroupTab,
      restoreWorkspaceLayoutNode,
      workspaceDropZoneAtPoint,
      applyWorkspaceTabDrop,
      workspaceToolbarPlacementForTab,
      returnWorkspaceToolbarToMount,
      workspaceVisiblePanes,
      setWorkspaceSplitRatio,
      focusWorkspacePane,
      duplicateWorkspaceTab,
      captureCurrentWorkspaceGroup,
      serializeWorkspaceGroupsForPreset,
      applyWorkspaceGroupPreset,
      restoreWorkspaceGroups,
      saveTabsState,
      restoreTabsState,
      switchWorkspaceGroup,
      beginWorkspaceGroupSelection,
      cancelWorkspaceGroupSelection,
      activateWorkspaceTabFromClick,
      beginWorkspaceGroupDrag,
      dropWorkspaceGroup,
      addTab,
      setWorkspaceTabConnectionStatus,
      renderTabContent,
      syncWorkspaceTabActivation,
      activateTab,
      closeTabsByKey,
      setLayout:value => { workspaceLayout = value; },
      getLayout:() => workspaceLayout,
      setFocusedPane:value => { focusedPaneId = value; },
      getFocusedPane:() => focusedPaneId,
      setTabs:value => { tabs = value; },
      getTabs:() => tabs,
      setWorkspaceGroups:(value, activeId) => { workspaceGroups = value; activeWorkspaceGroupId = activeId; },
      setWorkspacePaneNode:(paneId, node) => workspacePaneNodes.set(paneId, node),
      getWorkspaceGroups:() => workspaceGroups,
      getActiveWorkspaceGroupId:() => activeWorkspaceGroupId,
      getWorkspaceGroupSelectionMode:() => workspaceGroupSelectionMode,
      getTitleCalls:() => titleCalls,
      getWorkspaceSelectedTabKeys:() => [...workspaceSelectedTabKeys],
      resetSerials:() => { workspacePaneSerial = 1; workspaceSplitSerial = 0; }
    };`;

  vm.runInNewContext(source, sandbox, {filename, timeout:5000});
  return {api:sandbox.__dockingModel, sandbox, storage};
}

function loadLegacyWorkspaceModel() {
  const noop = () => {};
  const storage = new Map();
  const sandbox = {
    console,
    Map,
    Set,
    Date,
    Math,
    JSON,
    storage,
    tabs:[],
    activeTabKey:"",
    activeView:"welcome",
    responsiveLayoutMobile:false,
    runtimeSettings:{saved:{restore_workspace_tabs:true}},
    terminalSessions:new Map(),
    sftpDisconnectedTabs:new Set(),
    sftpViewStates:new Map(),
    isMobileLayout:() => false,
    requestAnimationFrame:callback => { callback(); return 1; },
    cancelAnimationFrame:noop,
    localStorage:{
      getItem:key => storage.get(key) || null,
      setItem:(key, value) => storage.set(key, String(value))
    },
    window:{restoringTabs:false, addEventListener:noop, removeEventListener:noop},
    document:{body:{classList:{add:noop, remove:noop, toggle:noop}}}
  };
  sandbox.globalThis = sandbox;

  const filename = path.join(root, "public", "app-workspace.js");
  const source = fs.readFileSync(filename, "utf8")
    .replace(/\r?\ninitActivityBarSizing\(\);\r?\ninitOperationPaneSizing\(\);\s*$/, "")
    + `\nrenderTabs = () => {};
      revealWorkspaceTab = () => {};
      renderTabContent = () => {};
      renderWelcome = () => {};
      closeTerminalSession = () => {};
      globalThis.__legacyWorkspaceModel = {
        addTab,
        activateTab,
        closeTabsByKey,
        persistableTabs,
        saveTabsState,
        restoreTabsState,
        setTabs:value => { tabs = value; },
        getTabs:() => tabs,
        getActiveTabKey:() => activeTabKey,
        storage
      };`;

  vm.runInNewContext(source, sandbox, {filename, timeout:5000});
  return sandbox.__legacyWorkspaceModel;
}

function pane(id, tabs=[]) {
  return {type:"pane", id, tabs:[...tabs], activeTabKey:tabs[0] || ""};
}

function split(id, direction, first, second, ratio=0.5) {
  return {type:"split", id, direction, ratio, first, second};
}

function fakePane(rect, tabRects=[]) {
  const tabNodes = tabRects.map(tabRect => ({
    getBoundingClientRect:() => ({
      ...tabRect,
      right:tabRect.right ?? tabRect.left + tabRect.width
    })
  }));
  const tabsShell = {
    getBoundingClientRect:() => ({left:rect.left, right:rect.right, top:-32, bottom:-1, width:rect.width, height:31}),
    querySelectorAll:() => tabNodes
  };
  const workspace = {getBoundingClientRect:() => rect};
  return {querySelector:selector => selector === ".tabs-shell" ? tabsShell : selector === ".workspace" ? workspace : null};
}

function runWorkspaceDockingChecks({silent=false}={}) {
  const checks = [];
  const check = (name, task) => {
    try {
      task();
      checks.push({name, pass:true});
      if (!silent) console.log(`[OK] ${name}`);
    } catch (error) {
      checks.push({name, pass:false, detail:error.message});
      if (!silent) console.error(`[FAIL] ${name} - ${error.message}`);
    }
  };

  const {api, sandbox, storage} = loadDockingModel();

  check("nested pane and split trees remain addressable", () => {
    const layout = split("split-1", "row", pane("pane-1", ["terminal-1"]), split(
      "split-2",
      "column",
      pane("pane-2", ["sftp-1"]),
      pane("pane-3", ["settings"]),
      0.6
    ));
    api.setLayout(layout);
    assert.equal(api.workspaceLeaves().map(item => item.id).join(","), "pane-1,pane-2,pane-3");
    assert.equal(api.workspaceFindPane("pane-3").activeTabKey, "settings");
    assert.equal(api.workspaceFindSplit("split-2").direction, "column");

    const nested = split("split-3", "column", pane("pane-4", ["terminal-2"]), layout.first);
    api.setLayout(api.workspaceReplacePaneWithSplit("pane-1", nested));
    assert.equal(api.workspaceLeaves().map(item => item.id).join(","), "pane-4,pane-1,pane-2,pane-3");
  });

  check("closing an inactive pane's active tab rerenders its replacement content", () => {
    const left = pane("pane-close-left", ["close-left"]);
    const right = pane("pane-close-right", ["close-right-a", "close-right-b"]);
    right.activeTabKey = "close-right-a";
    api.setTabs([
      {key:"close-left", title:"Left", kind:"settings", closable:true},
      {key:"close-right-a", title:"Right A", kind:"settings", closable:true},
      {key:"close-right-b", title:"Right B", kind:"settings", closable:true}
    ]);
    api.setLayout(split("split-close", "row", left, right));
    api.setFocusedPane(left.id);
    const rendered = [];
    const previousRenderPane = sandbox.renderWorkspacePaneContent;
    sandbox.renderWorkspacePaneContent = paneId => rendered.push(paneId);
    try {
      api.closeTabsByKey(["close-right-a"], "close-right-a");
    } finally {
      sandbox.renderWorkspacePaneContent = previousRenderPane;
    }
    assert.equal(api.workspaceFindPane(right.id).activeTabKey, "close-right-b");
    assert.ok(rendered.includes(right.id), "the non-focused pane must render its newly active tab");
  });

  check("incremental tab activation refreshes workspace group activity", () => {
    const activePane = pane("pane-activity", ["activity-tab"]);
    api.setTabs([{key:"activity-tab", title:"Activity", kind:"terminal", closable:true, activityState:"output"}]);
    api.setLayout(activePane);
    api.setFocusedPane(activePane.id);
    const tabClasses = new Set(["tab", "activity-output"]);
    const tabButton = {
      dataset:{tabKey:"activity-tab"},
      classList:{
        [Symbol.iterator]:() => tabClasses[Symbol.iterator](),
        contains:name => tabClasses.has(name),
        remove:(...names) => names.forEach(name => tabClasses.delete(name)),
        toggle:(name, enabled) => enabled ? tabClasses.add(name) : tabClasses.delete(name)
      },
      setAttribute:() => {}
    };
    api.setWorkspacePaneNode(activePane.id, {
      dataset:{paneId:activePane.id},
      classList:{toggle:() => {}},
      querySelector:() => null,
      querySelectorAll:selector => selector === ".tabs .tab[data-tab-key]" ? [tabButton] : []
    });
    let groupRenders = 0;
    const previousGroupRender = sandbox.renderWorkspaceGroupBar;
    sandbox.renderWorkspaceGroupBar = () => { groupRenders += 1; };
    try {
      api.syncWorkspaceTabActivation(activePane, "activity-tab");
    } finally {
      sandbox.renderWorkspaceGroupBar = previousGroupRender;
    }
    assert.equal(api.getTabs()[0].activityState, "");
    assert.equal(tabClasses.has("activity-output"), false, "the active tab DOM must clear its current activity marker immediately");
    assert.equal(tabClasses.has("active"), true, "the activated tab must remain visually selected");
    assert.equal(groupRenders, 1, "clearing tab activity must refresh the group activity marker");
  });

  check("Linux desktop manager tabs restore their content and legacy connection id", () => {
    api.renderTabContent({key:"linux-desktop-17", kind:"linux-desktop", id:17});
    assert.equal(sandbox.linuxDesktopManagerOpen.connectionId, 17);
    assert.equal(sandbox.linuxDesktopManagerOpen.updateTab, false);

    api.renderTabContent({key:"linux-desktop-29", kind:"linux-desktop"});
    assert.equal(sandbox.linuxDesktopManagerOpen.connectionId, 29);
    assert.equal(sandbox.linuxDesktopManagerOpen.updateTab, false);

    api.renderTabContent({key:"linux-desktop-select", kind:"linux-desktop"});
    assert.equal(sandbox.linuxDesktopManagerOpen.connectionId, 0);
  });

  check("empty panes collapse without flattening surviving nested splits", () => {
    const layout = split(
      "split-1",
      "row",
      pane("empty"),
      split("split-2", "column", pane("pane-2", ["a"]), pane("pane-3", ["b"]))
    );
    const pruned = api.pruneWorkspaceLayout(layout);
    assert.equal(pruned.id, "split-2");
    assert.equal(api.workspaceLeaves(pruned).map(item => item.id).join(","), "pane-2,pane-3");
  });

  check("workspace groups keep only their selected tabs while preserving internal splits", () => {
    const layout = split(
      "split-groups",
      "row",
      pane("pane-group-left", ["a", "b"]),
      pane("pane-group-right", ["c"])
    );
    const selected = api.workspaceFilterLayout(layout, new Set(["b", "c"]));
    const remaining = api.workspaceFilterLayout(layout, new Set(["a"]));
    assert.equal(selected.type, "split");
    assert.equal(api.workspaceLeaves(selected).map(item => item.tabs.join(",")).join("|"), "b|c");
    assert.equal(remaining.type, "pane");
    assert.equal(remaining.tabs.join(","), "a");
  });

  check("explicit workspace composition mode supports empty entry, left-click toggles and cancel", () => {
    api.setTabs([{key:"a", kind:"terminal"},{key:"b", kind:"sftp"}]);
    api.setLayout(pane("pane-select", ["a", "b"]));
    api.beginWorkspaceGroupSelection();
    assert.equal(api.getWorkspaceGroupSelectionMode(), true);
    assert.equal(api.getWorkspaceSelectedTabKeys().join(","), "");
    const click = {preventDefault:() => {}, stopPropagation:() => {}, ctrlKey:false, metaKey:false};
    api.activateWorkspaceTabFromClick(click, "a");
    api.activateWorkspaceTabFromClick(click, "b");
    assert.equal(api.getWorkspaceSelectedTabKeys().join(","), "a,b");
    api.activateWorkspaceTabFromClick(click, "a");
    assert.equal(api.getWorkspaceSelectedTabKeys().join(","), "b");
    api.cancelWorkspaceGroupSelection();
    assert.equal(api.getWorkspaceGroupSelectionMode(), false);
    assert.equal(api.getWorkspaceSelectedTabKeys().join(","), "");
  });

  check("workspace group drag sorting changes and persists group order", () => {
    const groups = [
      {id:"workspace-main", name:"Main", tabs:[{key:"a", kind:"terminal"}], layout:pane("pane-a", ["a"]), activeTabKey:"a", focusedPaneId:"pane-a"},
      {id:"workspace-group-1", name:"One", tabs:[{key:"b", kind:"sftp"}], layout:pane("pane-b", ["b"]), activeTabKey:"b", focusedPaneId:"pane-b"},
      {id:"workspace-group-2", name:"Two", tabs:[{key:"c", kind:"terminal"}], layout:pane("pane-c", ["c"]), activeTabKey:"c", focusedPaneId:"pane-c"}
    ];
    api.setWorkspaceGroups(groups, "workspace-main");
    api.setTabs(groups[0].tabs);
    api.setLayout(groups[0].layout);
    api.setFocusedPane("pane-a");
    sandbox.activeTabKey = "a";
    const classList = {add:() => {}, remove:() => {}};
    api.beginWorkspaceGroupDrag({stopPropagation:() => {}, dataTransfer:{setData:() => {}}, currentTarget:{classList}}, "workspace-group-2");
    api.dropWorkspaceGroup({preventDefault:() => {}, stopPropagation:() => {}, clientX:0, currentTarget:{closest:() => ({getBoundingClientRect:() => ({left:0, width:100})})}}, "workspace-main");
    assert.equal(api.getWorkspaceGroups().map(group => group.id).join(","), "workspace-group-2,workspace-main,workspace-group-1");
    const saved = JSON.parse(storage.get("workspaceTabs"));
    assert.equal(saved.workspaceGroups.map(group => group.id).join(","), "workspace-group-2,workspace-main,workspace-group-1");
  });

  check("switching workspace groups captures the old layout and restores the target independently", () => {
    sandbox.__mobile = false;
    const groupA = {
      id:"workspace-main",
      name:"Main",
      tabs:[{key:"a", kind:"terminal", title:"A"}],
      layout:pane("pane-a", ["a"]),
      activeTabKey:"a",
      focusedPaneId:"pane-a"
    };
    const groupB = {
      id:"workspace-group-1",
      name:"Ops",
      tabs:[{key:"b", kind:"sftp", title:"B"}],
      layout:pane("pane-b", ["b"]),
      activeTabKey:"b",
      focusedPaneId:"pane-b"
    };
    api.setWorkspaceGroups([groupA, groupB], groupA.id);
    api.setTabs(groupA.tabs);
    api.setLayout(groupA.layout);
    api.setFocusedPane("pane-a");
    sandbox.activeTabKey = "a";

    api.switchWorkspaceGroup(groupB.id, {notify:false});

    assert.equal(api.getActiveWorkspaceGroupId(), groupB.id);
    assert.equal(api.getTabs().map(tab => tab.key).join(","), "b");
    assert.equal(api.workspaceLeaves().map(item => item.id).join(","), "pane-b");
    assert.equal(api.getWorkspaceGroups()[0].tabs.map(tab => tab.key).join(","), "a");
    const saved = JSON.parse(storage.get("workspaceTabs"));
    assert.equal(saved.activeWorkspaceGroupId, groupB.id);
    assert.equal(saved.workspaceGroups.length, 2);
    assert.equal(saved.workspaceGroups[0].tabs[0].key, "a");
  });

  check("stateless singleton tab keys can persist independently in different workspace groups", () => {
    const restored = api.restoreWorkspaceGroups({
      activeWorkspaceGroupId:"workspace-main",
      workspaceGroups:[
        {id:"workspace-main", name:"Main", tabs:[{key:"settings", kind:"settings"}]},
        {id:"workspace-group-2", name:"Other", tabs:[{key:"settings", kind:"settings"}]}
      ]
    });
    assert.equal(restored.tabs[0].key, "settings");
    assert.equal(api.getWorkspaceGroups()[1].tabs[0].key, "settings");
  });

  check("restored workspace tabs discard stale connection colors and do not persist runtime status", () => {
    const restoredModel = loadDockingModel();
    const restoredTabs = [
      {key:"terminal-restored", kind:"terminal", connectionStatus:"connected"},
      {key:"sftp-restored", kind:"sftp", connectionStatus:"connecting"},
      {key:"remote-terminal-restored", kind:"remote-terminal", connectionStatus:"connected"},
      {key:"vnc-restored", kind:"remote-desktop", protocol:"vnc", connectionStatus:"connected"},
      {key:"rdp-restored", kind:"remote-desktop", protocol:"rdp", connectionStatus:"connected"}
    ];
    restoredModel.storage.set("workspaceTabs", JSON.stringify({
      activeWorkspaceGroupId:"workspace-main",
      workspaceGroups:[{
        id:"workspace-main",
        name:"",
        tabs:restoredTabs,
        layout:pane("pane-restored", restoredTabs.map(tab => tab.key)),
        activeTabKey:"terminal-restored",
        focusedPaneId:"pane-restored"
      }]
    }));

    assert.equal(restoredModel.api.restoreTabsState(), true);
    const byKey = new Map(restoredModel.api.getTabs().map(tab => [tab.key, tab]));
    for (const key of ["terminal-restored", "sftp-restored", "remote-terminal-restored", "vnc-restored"]) {
      assert.equal(byKey.get(key).connectionStatus, "disconnected", `${key} must restart disconnected`);
    }
    assert.equal(Object.hasOwn(byKey.get("rdp-restored"), "connectionStatus"), false);
    const saved = JSON.parse(restoredModel.storage.get("workspaceTabs"));
    assert.equal(saved.workspaceGroups[0].tabs.every(tab => !Object.hasOwn(tab, "connectionStatus")), true);
  });

  check("legacy workspace restore also resets and omits connection status", () => {
    const legacy = loadLegacyWorkspaceModel();
    legacy.storage.set("workspaceTabs", JSON.stringify({
      activeTabKey:"terminal-legacy",
      tabs:[
        {key:"terminal-legacy", kind:"terminal", connectionStatus:"connected"},
        {key:"sftp-legacy", kind:"sftp", connectionStatus:"connecting"}
      ]
    }));
    assert.equal(legacy.restoreTabsState(), true);
    assert.equal(legacy.getTabs().every(tab => tab.connectionStatus === "disconnected"), true);
    const saved = JSON.parse(legacy.storage.get("workspaceTabs"));
    assert.equal(saved.tabs.every(tab => !Object.hasOwn(tab, "connectionStatus")), true);
  });

  check("background sessions can resolve and update tabs in inactive workspace groups", () => {
    const active = {id:"workspace-main", name:"Main", tabs:[{key:"active", kind:"terminal"}], layout:pane("pane-active", ["active"]), activeTabKey:"active", focusedPaneId:"pane-active"};
    const hidden = {id:"workspace-group-3", name:"Hidden", tabs:[{key:"hidden", kind:"sftp", connectionStatus:"connecting"}], layout:pane("pane-hidden", ["hidden"]), activeTabKey:"hidden", focusedPaneId:"pane-hidden"};
    api.setWorkspaceGroups([active, hidden], active.id);
    api.setTabs(active.tabs);
    api.setLayout(active.layout);
    api.setFocusedPane("pane-active");
    sandbox.activeTabKey = "active";

    assert.equal(api.workspaceHasTabKey("hidden"), true);
    assert.equal(api.workspaceTabByKey("hidden").kind, "sftp");
    assert.equal(api.workspaceAllTabs().map(tab => tab.key).join(","), "active,hidden");
    api.setWorkspaceTabConnectionStatus("hidden", "connected");
    assert.equal(hidden.tabs[0].connectionStatus, "connected");
  });

  check("workspace group presets preserve order, names and recursive split trees", () => {
    const first = {
      id:"workspace-main",
      name:"主工作区",
      tabs:[{key:"a", kind:"terminal", title:"A"}],
      layout:pane("pane-a", ["a"]),
      activeTabKey:"a",
      focusedPaneId:"pane-a"
    };
    const second = {
      id:"workspace-group-9",
      name:"开发组",
      tabs:[{key:"b", kind:"sftp", title:"B"},{key:"c", kind:"terminal", title:"C"}],
      layout:split("split-preset", "row", pane("pane-b", ["b"]), pane("pane-c", ["c"])),
      activeTabKey:"c",
      focusedPaneId:"pane-c"
    };
    api.setWorkspaceGroups([first, second], second.id);
    api.setTabs(second.tabs);
    api.setLayout(second.layout);
    api.setFocusedPane("pane-c");
    sandbox.activeTabKey = "c";
    const preset = api.serializeWorkspaceGroupsForPreset();
    assert.deepEqual(preset.map(group => group.name), ["主工作区", "开发组"]);
    assert.equal(preset[1].layout.type, "split");
    assert.equal(preset[1].layout.first.tabs[0], "b");
    api.applyWorkspaceGroupPreset({workspaceGroups:preset, activeWorkspaceGroupId:"workspace-group-9"});
    assert.equal(api.getActiveWorkspaceGroupId(), "workspace-group-9");
    assert.equal(api.getWorkspaceGroups()[1].name, "开发组");
    assert.equal(api.workspaceLeaves().map(item => item.id).join(","), "pane-b,pane-c");
  });

  check("recursive layouts serialize and restore with bounded ratios", () => {
    const layout = split(
      "split-10",
      "row",
      pane("pane-10", ["a"]),
      split("split-11", "column", pane("pane-11", ["b"]), pane("pane-12", ["c"]), 0.74),
      0.22
    );
    api.setLayout(layout);
    const saved = api.serializeWorkspaceLayout();
    const restored = api.restoreWorkspaceLayoutNode(
      {...saved, ratio:99},
      new Set(["a", "b", "c"]),
      new Set(),
      new Set(),
      new Set()
    );
    assert.equal(restored.ratio, 0.85);
    assert.equal(restored.second.direction, "column");
    assert.equal(api.workspaceLeaves(restored).map(item => item.activeTabKey).join(","), "a,b,c");
  });

  check("all four pane-edge drop zones can create another split", () => {
    sandbox.__mobile = false;
    const target = fakePane({left:0, right:100, top:0, bottom:100, width:100, height:100});
    assert.equal(api.workspaceDropZoneAtPoint(target, 5, 50).zone, "left");
    assert.equal(api.workspaceDropZoneAtPoint(target, 95, 50).zone, "right");
    assert.equal(api.workspaceDropZoneAtPoint(target, 50, 5).zone, "top");
    assert.equal(api.workspaceDropZoneAtPoint(target, 50, 95).zone, "bottom");
    assert.equal(api.workspaceDropZoneAtPoint(target, 50, 50).zone, "center");
  });

  check("splitting a background tab keeps the previously active tab in the source pane", () => {
    api.resetSerials();
    api.setTabs([
      {key:"sftp-1", kind:"sftp"},
      {key:"sftp-2", kind:"sftp"},
      {key:"terminal-3", kind:"terminal"}
    ]);
    api.setLayout(pane("pane-source", ["sftp-1", "sftp-2", "terminal-3"]));
    api.setFocusedPane("pane-source");
    const applied = api.applyWorkspaceTabDrop(
      {key:"sftp-2", sourcePaneId:"pane-source", sourceActiveTabKey:"sftp-1"},
      {paneId:"pane-source", zone:"right"}
    );
    assert.equal(applied, true);
    const source = api.workspaceLeaves().find(item => item.tabs.includes("sftp-1"));
    const destination = api.workspaceLeaves().find(item => item.tabs.includes("sftp-2"));
    assert.equal(source.activeTabKey, "sftp-1");
    assert.deepEqual([...source.tabs], ["sftp-1", "terminal-3"]);
    assert.equal(destination.activeTabKey, "sftp-2");
  });

  check("splitting the active middle tab returns the source pane to its left neighbor", () => {
    api.resetSerials();
    api.setTabs([
      {key:"terminal-1", kind:"terminal"},
      {key:"sftp-1", kind:"sftp"},
      {key:"terminal-2", kind:"terminal"}
    ]);
    const layout = pane("pane-source", ["terminal-1", "sftp-1", "terminal-2"]);
    layout.activeTabKey = "sftp-1";
    api.setLayout(layout);
    api.setFocusedPane("pane-source");
    const applied = api.applyWorkspaceTabDrop(
      {key:"sftp-1", sourcePaneId:"pane-source", sourceActiveTabKey:"sftp-1"},
      {paneId:"pane-source", zone:"right"}
    );
    assert.equal(applied, true);
    const source = api.workspaceLeaves().find(item => item.tabs.includes("terminal-1"));
    const destination = api.workspaceLeaves().find(item => item.tabs.includes("sftp-1"));
    assert.deepEqual([...source.tabs], ["terminal-1", "terminal-2"]);
    assert.equal(source.activeTabKey, "terminal-1");
    assert.equal(destination.activeTabKey, "sftp-1");
  });

  check("focusing another split pane updates the native workspace title", () => {
    api.setTabs([
      {key:"terminal-left", kind:"terminal", viewName:"terminal", title:"Linux图形界面测试", subtitle:"root@192.168.31.77:22"},
      {key:"terminal-right", kind:"terminal", viewName:"terminal", title:"Linux图形界面测试", subtitle:"root@192.168.31.76:22"}
    ]);
    api.setLayout({
      type:"split",
      id:"split-title",
      direction:"row",
      ratio:0.5,
      first:pane("pane-title-left", ["terminal-left"]),
      second:pane("pane-title-right", ["terminal-right"])
    });
    for (const paneId of ["pane-title-left", "pane-title-right"]) {
      api.setWorkspacePaneNode(paneId, {
        dataset:{paneId},
        classList:{toggle:() => {}},
        querySelector:() => null
      });
    }
    api.setFocusedPane("pane-title-left");
    const calls = api.getTitleCalls();
    calls.length = 0;
    api.focusWorkspacePane("pane-title-right");
    assert.equal(calls.length, 1);
    assert.equal(calls[0][0], "Linux图形界面测试");
    assert.equal(calls[0][1], "root@192.168.31.76:22");
    assert.equal(calls[0][3], "terminal-right");
    assert.equal(calls[0][4].kind, "terminal");
  });

  check("tab-strip drops resolve an exact insertion index", () => {
    sandbox.__mobile = false;
    const target = fakePane(
      {left:0, right:300, top:0, bottom:100, width:300, height:100},
      [
        {left:20, width:80},
        {left:100, width:90},
        {left:190, width:70}
      ]
    );
    assert.equal(api.workspaceDropZoneAtPoint(target, 25, -16).index, 0);
    assert.equal(api.workspaceDropZoneAtPoint(target, 135, -16).index, 1);
    assert.equal(api.workspaceDropZoneAtPoint(target, 255, -16).index, 3);
  });

  check("terminal and SFTP toolbar placements stay independent in each layout mode", () => {
    api.setTabs([
      {key:"terminal-a", kind:"terminal"},
      {key:"sftp-a", kind:"sftp"}
    ]);
    sandbox.runtimeSettings.saved.workspace_toolbar_placement = {
      unsplit:{terminal:"tab", sftp:"header"},
      split:{terminal:"header", sftp:"tab"}
    };
    sandbox.__mobile = false;
    api.setLayout(pane("pane-toolbar", ["terminal-a", "sftp-a"]));
    assert.equal(api.workspaceToolbarPlacementForTab("terminal-a"), "tab");
    assert.equal(api.workspaceToolbarPlacementForTab("sftp-a"), "header");
    api.setLayout(split(
      "split-toolbar",
      "row",
      pane("pane-toolbar-left", ["terminal-a"]),
      pane("pane-toolbar-right", ["sftp-a"])
    ));
    assert.equal(api.workspaceToolbarPlacementForTab("terminal-a"), "header");
    assert.equal(api.workspaceToolbarPlacementForTab("sftp-a"), "tab");
    sandbox.__mobile = true;
    assert.equal(api.workspaceToolbarPlacementForTab("terminal-a"), "tab");
    assert.equal(api.workspaceToolbarPlacementForTab("sftp-a"), "tab");
    sandbox.__mobile = false;
  });

  check("toolbars with a removed owner mount are discarded", () => {
    api.setTabs([{key:"terminal-stale", kind:"terminal"}]);
    api.setLayout(pane("pane-stale", ["terminal-stale"]));
    let removed = 0;
    const toolbar = {
      dataset:{workspaceToolbarKind:"terminal", workspaceTabKey:"terminal-stale"},
      classList:{contains:value => value === "terminal-toolbar", remove:() => {}},
      closest:() => null,
      remove:() => { removed += 1; }
    };

    api.returnWorkspaceToolbarToMount(toolbar);

    assert.equal(removed, 1);
  });

  check("split ratios clamp and persist with the workspace tree", () => {
    api.setTabs([
      {key:"a", kind:"terminal", title:"A"},
      {key:"b", kind:"sftp", title:"B"}
    ]);
    api.setLayout(split("split-20", "row", pane("pane-20", ["a"]), pane("pane-21", ["b"])));
    api.setFocusedPane("pane-20");
    sandbox.activeTabKey = "a";
    api.setWorkspaceSplitRatio("split-20", 2);
    assert.equal(api.getLayout().ratio, 0.85);
    let saved = JSON.parse(storage.get("workspaceTabs"));
    assert.equal(saved.layout.ratio, 0.85);
    api.setWorkspaceSplitRatio("split-20", -2);
    saved = JSON.parse(storage.get("workspaceTabs"));
    assert.equal(saved.layout.ratio, 0.15);
  });

  check("duplicating a terminal tab passes a distinct session key", () => {
    api.setTabs([{key:"terminal-7-1", kind:"terminal", id:7, title:"Host", viewName:"terminal", closable:true}]);
    api.setLayout(pane("pane-30", ["terminal-7-1"]));
    api.setFocusedPane("pane-30");
    let terminalCall = null;
    sandbox.openTerminal = (id, updateTab, existingKey, title) => {
      terminalCall = {id, updateTab, existingKey, title};
      api.addTab(existingKey, title, "", "terminal", true, {kind:"terminal", id});
    };
    api.duplicateWorkspaceTab("terminal-7-1");
    const keys = api.getTabs().map(item => item.key);
    assert.equal(new Set(keys).size, 2);
    assert.equal(terminalCall.id, 7);
    assert.equal(terminalCall.updateTab, true);
    assert.equal(terminalCall.existingKey, "terminal-7-2");
    assert.equal(terminalCall.title, "Host #2");
  });

  check("ordinary workspace tabs also duplicate with independent keys", () => {
    api.setTabs([{key:"settings", kind:"settings", title:"Settings", subtitle:"General", viewName:"settings", closable:true}]);
    api.setLayout(pane("pane-31", ["settings"]));
    api.setFocusedPane("pane-31");
    sandbox.openSettings = () => {};
    api.duplicateWorkspaceTab("settings");
    const copied = api.getTabs().find(item => item.key !== "settings");
    assert.ok(copied);
    assert.match(copied.key, /^settings-copy-\d+$/);
    assert.equal(copied.kind, "settings");
    assert.equal(api.workspaceFindPane("pane-31").activeTabKey, copied.key);
  });

  check("new tabs open after the active tab and close back to it", () => {
    api.setTabs([
      {key:"first", kind:"terminal", title:"First"},
      {key:"second", kind:"terminal", title:"Second"},
      {key:"third", kind:"terminal", title:"Third"}
    ]);
    api.setLayout(pane("pane-mru", ["first", "second", "third"]));
    api.setFocusedPane("pane-mru");
    sandbox.activeTabKey = "first";

    api.activateTab("second");
    api.addTab("settings", "Settings", "General", "settings", true, {kind:"settings"});
    assert.equal(api.workspaceFindPane("pane-mru").activeTabKey, "settings");
    assert.equal(api.workspaceFindPane("pane-mru").tabs.join(","), "first,second,settings,third");
    assert.equal(api.getTabs().map(tab => tab.key).join(","), "first,second,settings,third");

    api.closeTabsByKey(["settings"], "settings");
    assert.equal(api.workspaceFindPane("pane-mru").activeTabKey, "second");
    assert.equal(sandbox.activeTabKey, "second");
  });

  check("legacy tabs also open after the active tab and close back to it", () => {
    const legacy = loadLegacyWorkspaceModel();
    legacy.addTab("first", "First", "", "terminal", true, {kind:"terminal"});
    legacy.addTab("second", "Second", "", "terminal", true, {kind:"terminal"});
    legacy.addTab("third", "Third", "", "terminal", true, {kind:"terminal"});
    legacy.activateTab("second");
    legacy.addTab("settings", "Settings", "General", "settings", true, {kind:"settings"});
    assert.equal(legacy.getTabs().map(tab => tab.key).join(","), "first,second,settings,third");
    legacy.closeTabsByKey(["settings"], "settings");
    assert.equal(legacy.getActiveTabKey(), "second");
    assert.equal(legacy.getTabs().map(tab => tab.key).join(","), "first,second,third");
  });

  check("recent-tab fallback stays inside its pane and skips tabs closed in the same batch", () => {
    api.setTabs([
      {key:"left-a", kind:"terminal"},
      {key:"left-b", kind:"terminal"},
      {key:"left-c", kind:"settings"},
      {key:"left-d", kind:"settings"},
      {key:"right-a", kind:"sftp"},
      {key:"right-b", kind:"sftp"}
    ]);
    api.setLayout(split(
      "split-mru",
      "row",
      pane("pane-mru-left", ["left-a", "left-b", "left-c", "left-d"]),
      pane("pane-mru-right", ["right-a", "right-b"])
    ));
    api.setFocusedPane("pane-mru-left");
    sandbox.activeTabKey = "left-a";

    api.activateTab("left-b");
    api.activateTab("left-c");
    api.activateTab("right-b");
    api.activateTab("left-d");
    api.closeTabsByKey(["left-d", "left-c"], "left-d");

    assert.equal(api.workspaceFindPane("pane-mru-left").activeTabKey, "left-b");
    assert.equal(api.workspaceFindPane("pane-mru-right").activeTabKey, "right-b");
    assert.equal(sandbox.activeTabKey, "left-b");
  });

  check("recent-tab history remains runtime-only", () => {
    const saved = JSON.parse(storage.get("workspaceTabs"));
    assert.equal(JSON.stringify(saved).includes("workspacePaneTabHistory"), false);
    assert.equal(JSON.stringify(saved).includes("tabHistory"), false);
  });

  check("mobile layout exposes only the focused pane", () => {
    api.setLayout(split("split-40", "row", pane("pane-40", ["a"]), pane("pane-41", ["b"])));
    api.setFocusedPane("pane-41");
    sandbox.__mobile = true;
    assert.equal(api.workspaceVisiblePanes().map(item => item.id).join(","), "pane-41");
    sandbox.__mobile = false;
    assert.equal(api.workspaceVisiblePanes().length, 2);
  });

  const failures = checks.filter(item => !item.pass).map(item => `${item.name}: ${item.detail}`);
  return {passed:failures.length === 0, failures, checks};
}

if (require.main === module) {
  const result = runWorkspaceDockingChecks();
  if (!result.passed) process.exit(1);
  console.log(`Workspace docking checks passed: ${result.checks.length}`);
}

module.exports = runWorkspaceDockingChecks;
