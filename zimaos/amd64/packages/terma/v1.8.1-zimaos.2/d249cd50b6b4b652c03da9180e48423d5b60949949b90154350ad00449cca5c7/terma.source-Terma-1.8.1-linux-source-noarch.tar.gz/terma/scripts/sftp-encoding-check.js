const assert = require("node:assert");
const iconv = require("iconv-lite");
const { decodeRemoteFilenameOutput, decodeRemoteText, encodeRemoteText, normalizeTextEncoding, remotePathBytesOperand, remotePathOperand } = require("../dist/sftp");

const sample = "你好，Terma\r\n";
const samples = {
  shift_jis: "こんにちは、Terma\r\n",
  "euc-kr": "안녕하세요, Terma\r\n",
  latin1: "Terma café\r\n"
};
for (const encoding of ["utf8", "utf8bom", "gb18030", "gbk", "big5", "shift_jis", "euc-kr", "latin1"]) {
  const source = samples[encoding] || sample;
  const encoded = encodeRemoteText(source, encoding);
  const decoded = decodeRemoteText(encoded, encoding);
  assert.strictEqual(decoded.content, source, `${encoding} round trip`);
  assert.strictEqual(decoded.encoding, encoding);
}

const bom = encodeRemoteText(sample, "utf8bom");
assert.deepStrictEqual([...bom.subarray(0, 3)], [0xef, 0xbb, 0xbf]);
assert.strictEqual(decodeRemoteText(bom, "auto").encoding, "utf8bom");
assert.strictEqual(decodeRemoteText(Buffer.from(sample, "utf8"), "auto").encoding, "utf8");
assert.strictEqual(decodeRemoteText(encodeRemoteText(sample, "gb18030"), "auto").encoding, "gb18030");
assert.throws(() => normalizeTextEncoding("unsupported"), /不支持/);

const filenameSample = "故障告警接口";
for (const encoding of ["utf8", "gb18030", "gbk", "big5"]) {
  const connection = { sftp_filename_encoding:encoding };
  assert.strictEqual(decodeRemoteFilenameOutput(connection, iconv.encode(filenameSample, encoding)), filenameSample, `${encoding} filename decode`);
}
const gbkOperand = remotePathOperand({ sftp_filename_encoding:"gbk" }, `目录/${filenameSample}`);
assert.match(gbkOperand, /printf '%b'/);
assert.ok(!gbkOperand.includes(filenameSample), "non-UTF-8 path is emitted as bytes");
assert.strictEqual(remotePathOperand({ sftp_filename_encoding:"utf8" }, "目录/a.txt"), "'目录/a.txt'");
const rawFilenamePath = Buffer.from([0x2f, 0x74, 0x6d, 0x70, 0x2f, 0x31, 0x30, 0x6b, 0xff, 0xfe, 0x2e, 0x74, 0x78, 0x74]);
const rawFilenameText = iconv.decode(rawFilenamePath, "utf8");
assert.match(remotePathBytesOperand({ sftp_filename_encoding:"utf8" }, rawFilenamePath.toString("base64"), rawFilenameText), /printf '%b'/);
assert.throws(() => remotePathBytesOperand({ sftp_filename_encoding:"utf8" }, rawFilenamePath.toString("base64"), "/tmp/not-the-same-name"), /不匹配/);

console.log("SFTP 编码检查通过：文本 BOM/自动回退/8 种编码往返及文件名转码");
