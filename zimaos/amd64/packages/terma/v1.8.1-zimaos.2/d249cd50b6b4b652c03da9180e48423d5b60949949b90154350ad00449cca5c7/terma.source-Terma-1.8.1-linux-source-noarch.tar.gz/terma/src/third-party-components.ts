type ThirdPartyComponent = {
  name:string;
  version:string;
  license:string;
  project_url:string;
  use:string;
};

const THIRD_PARTY_COMPONENTS:ThirdPartyComponent[] = [
  {name:"xterm.js", version:"6.0.0", license:"MIT", project_url:"https://github.com/xtermjs/xterm.js", use:"terminal"},
  {name:"Ace Editor", version:"1.44.0", license:"BSD-3-Clause", project_url:"https://github.com/ajaxorg/ace-builds", use:"sftp_text_edit"},
  {name:"jsdiff", version:"9.0.0", license:"BSD-3-Clause", project_url:"https://github.com/kpdecker/jsdiff", use:"sftp_diff"},
  {name:"jsPDF", version:"4.2.1", license:"MIT", project_url:"https://github.com/parallax/jsPDF", use:"browser_pdf_generation"},
  {name:"svg2pdf.js", version:"2.8.1", license:"MIT", project_url:"https://github.com/yWorks/svg2pdf.js", use:"svg_vector_pdf_export"},
  {name:"Noto Sans SC", version:"2.004", license:"OFL-1.1", project_url:"https://github.com/notofonts/noto-cjk", use:"svg_pdf_cjk_font"},
  {name:"noVNC", version:"1.7.0", license:"MPL-2.0", project_url:"https://github.com/novnc/noVNC", use:"builtin_vnc"},
  {name:"TigerVNC Viewer", version:"1.16.2", license:"GPL-2.0-or-later", project_url:"https://github.com/TigerVNC/tigervnc", use:"bundled_vnc_client"},
  {name:"ZMODEM.js", version:"0.1.10", license:"Apache-2.0", project_url:"https://github.com/FGasper/zmodemjs", use:"zmodem_transfer"},
  {name:"ssh2", version:"1.17.0", license:"MIT", project_url:"https://github.com/mscdex/ssh2", use:"ssh_sftp_transport"},
  {name:"node-x11", version:"4.3.1", license:"MIT", project_url:"https://github.com/sidorares/node-x11", use:"x11_protocol_client"},
  {name:"i18next", version:"26.4.3", license:"MIT", project_url:"https://github.com/i18next/i18next", use:"interface_i18n"},
  {name:"Lucide", version:"1.55.0", license:"ISC", project_url:"https://lucide.dev", use:"interface_icons"},
  {name:"Electron", version:"44.7.0", license:"MIT", project_url:"https://github.com/electron/electron", use:"desktop_runtime"},
  {name:"node-pty", version:"1.1.0", license:"MIT", project_url:"https://github.com/microsoft/node-pty", use:"desktop_pty"},
  {name:"VcXsrv", version:"21.1.16.1", license:"GPL-3.0", project_url:"https://github.com/marchaesen/vcxsrv", use:"windows_x_server"}
];

function listThirdPartyComponents():ThirdPartyComponent[] {
  const desktopOnly = new Set(["Electron", "VcXsrv", "TigerVNC Viewer"]);
  return THIRD_PARTY_COMPONENTS.filter(item => process.env.TERMA_DISTRIBUTION !== "fnos" || !desktopOnly.has(item.name)).map(item => ({...item}));
}

module.exports = {listThirdPartyComponents};
