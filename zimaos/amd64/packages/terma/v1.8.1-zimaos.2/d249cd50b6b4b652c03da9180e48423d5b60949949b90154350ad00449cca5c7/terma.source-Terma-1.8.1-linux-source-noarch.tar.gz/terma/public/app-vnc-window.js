function isDetachedVncWindow() {
  return Boolean(window.termaVncDetached);
}

const browserDetachedVncWindows = new Map();
const browserDetachedVncReservations = new Map();

function activeVncDetachedBrowserReservation(profileId) {
  const id = Number(profileId || 0);
  const state = browserDetachedVncReservations.get(id);
  if (!state || state.status !== "pending" || !state.child || state.child.closed) {
    if (browserDetachedVncReservations.get(id) === state) browserDetachedVncReservations.delete(id);
    return null;
  }
  return state;
}

function reserveVncDetachedBrowserWindow(profileId) {
  const id = Number(profileId || 0);
  if (!Number.isInteger(id) || id <= 0 || window.termaDesktop?.openVncWindow) return null;
  const pending = activeVncDetachedBrowserReservation(id);
  if (pending) {
    const claim = {};
    pending.claims.add(claim);
    return {profileId:id, child:pending.child, created:false, blocked:false, pending:true, state:pending, claim};
  }
  const existing = browserDetachedVncWindows.get(id);
  if (existing && !existing.closed) return {profileId:id, child:existing, created:false, blocked:false, pending:false, committed:true};
  const child = window.open("", `terma-vnc-${id}`, "popup,width=1280,height=820");
  if (!child) return {profileId:id, child:null, created:false, blocked:true};
  const claim = {};
  const state = {profileId:id, child, status:"pending", claims:new Set([claim])};
  browserDetachedVncWindows.set(id, child);
  browserDetachedVncReservations.set(id, state);
  return {profileId:id, child, created:true, blocked:false, pending:true, state, claim};
}

function cancelReservedVncDetachedBrowserWindow(reservation) {
  if (!reservation || reservation.released) return;
  reservation.released = true;
  const id = Number(reservation.profileId || 0);
  const state = reservation.state;
  if (!state) return;
  state.claims.delete(reservation.claim);
  if (state.status !== "pending" || state.claims.size > 0) return;
  state.status = "cancelled";
  if (browserDetachedVncReservations.get(id) === state) browserDetachedVncReservations.delete(id);
  if (state.child && !state.child.closed) state.child.close();
  if (browserDetachedVncWindows.get(id) === state.child) browserDetachedVncWindows.delete(id);
}

function commitReservedVncDetachedBrowserWindow(reservation, url) {
  if (!reservation || reservation.blocked) return null;
  const id = Number(reservation.profileId || 0);
  const child = reservation.child;
  if (!child || child.closed) return null;
  const state = reservation.state;
  if (state?.status === "pending") {
    if (browserDetachedVncReservations.get(id) !== state) return null;
    state.status = "committed";
    browserDetachedVncReservations.delete(id);
    child.location.replace(url);
  } else if (state?.status === "cancelled") return null;
  browserDetachedVncWindows.set(id, child);
  reservation.committed = true;
  return child;
}

function embeddedVncSessionKeysForProfile(profileId, preferredKey="") {
  const id = Number(profileId || 0);
  const keys = new Set();
  if (preferredKey && Number(vncSessions.get(preferredKey)?.profile?.id || 0) === id) keys.add(preferredKey);
  for (const [key, session] of vncSessions) {
    if (!String(key).startsWith("detached-vnc-") && Number(session?.profile?.id || 0) === id) keys.add(key);
  }
  return [...keys];
}

function prepareVncManagementForDetachedWindow(profileId, preferredKey="") {
  if (isDetachedVncWindow()) return Promise.resolve(false);
  const id = Number(profileId || 0);
  const sessionKeys = embeddedVncSessionKeysForProfile(id, preferredKey);
  if (!sessionKeys.length) return Promise.resolve(false);
  for (const key of sessionKeys) {
    closeRemoteProtocolSession(key);
    setWorkspaceTabConnectionStatus(key, "disconnected");
  }
  return Promise.resolve(openRemoteDesktop(id, false, true)).then(() => true);
}

async function closeVncDetachedWindowForProfile(profileId) {
  const id = Number(profileId || 0);
  if (!Number.isInteger(id) || id <= 0 || isDetachedVncWindow()) return {ok:false, closed:false};
  if (window.termaDesktop?.closeVncWindowForProfile) return window.termaDesktop.closeVncWindowForProfile(id);
  const child = browserDetachedVncWindows.get(id);
  if (!child || child.closed) {
    browserDetachedVncWindows.delete(id);
    browserDetachedVncReservations.delete(id);
    return {ok:true, profileId:id, closed:false};
  }
  const pending = browserDetachedVncReservations.get(id);
  if (pending) pending.status = "cancelled";
  browserDetachedVncReservations.delete(id);
  child.close();
  browserDetachedVncWindows.delete(id);
  return {ok:true, profileId:id, closed:true};
}

async function openVncInNewWindow(profileId, key="", options={}) {
  const id = Number(profileId || 0);
  if (!Number.isInteger(id) || id <= 0) return notify(tr("remote:vnc_ui.detached_profile_missing", {defaultValue:"VNC 连接不存在"}), "error");
  let browserReservation = Number(options.browserReservation?.profileId || 0) === id ? options.browserReservation : null;
  try {
    if (window.termaDesktop?.openVncWindow) {
      const managementReady = prepareVncManagementForDetachedWindow(id, key);
      await window.termaDesktop.openVncWindow(id, {key});
      await managementReady;
      if (options.closeDetectionTab && key && tabs.some(tab => tab.key === key)) closeTabsByKey([key], key);
      return true;
    }
    const url = new URL(location.href);
    url.searchParams.set("termaVncWindow", String(id));
    browserReservation ||= reserveVncDetachedBrowserWindow(id);
    if (browserReservation?.blocked) throw new Error(tr("remote:vnc_ui.detached_open_failed", {defaultValue:"无法打开新窗口，请检查浏览器弹窗权限"}));
    const child = commitReservedVncDetachedBrowserWindow(browserReservation, url.href);
    if (!child) throw new Error(tr("remote:vnc_ui.detached_open_failed", {defaultValue:"无法打开新窗口，请检查浏览器弹窗权限"}));
    child.focus();
    await prepareVncManagementForDetachedWindow(id, key);
    if (options.closeDetectionTab && key && tabs.some(tab => tab.key === key)) closeTabsByKey([key], key);
    return true;
  } catch (error) {
    cancelReservedVncDetachedBrowserWindow(browserReservation);
    notify(window.termaDesktop?.openVncWindow
      ? tr("remote:vnc_ui.detached_open_failed", {defaultValue:"无法打开 VNC 新窗口，请重试"})
      : error.message || tr("remote:vnc_ui.detached_open_failed", {defaultValue:"无法打开 VNC 新窗口"}), "error");
    return false;
  }
}

async function prepareEmbeddedVncWindowSwitch(profileId) {
  if (isDetachedVncWindow()) return true;
  try {
    await closeVncDetachedWindowForProfile(profileId);
    return true;
  } catch (error) {
    notify(error.message || tr("remote:vnc_ui.window_switch_failed", {defaultValue:"无法切换 VNC 显示窗口"}), "error");
    return false;
  }
}

async function closeDetachedVncWindow(key="") {
  if (key) closeRemoteProtocolSession(key);
  if (window.termaDesktop?.closeVncWindow) return window.termaDesktop.closeVncWindow();
  window.close();
  return {ok:true};
}

async function openDetachedVncConnectionSettings(profileId) {
  const id = Number(profileId || 0);
  if (!Number.isInteger(id) || id <= 0) return false;
  try {
    if (window.termaDesktop?.openRemoteProfileSettings) {
      const result = await window.termaDesktop.openRemoteProfileSettings(id);
      if (result?.ok !== false) return true;
      throw new Error(tr("remote:vnc_ui.connection_settings_failed", {defaultValue:"无法打开连接设置"}));
    }
    const opener = window.opener;
    if (opener && !opener.closed) {
      opener.focus?.();
      if (typeof opener.editRemoteProfile === "function") {
        opener.editRemoteProfile(id);
        return true;
      }
    }
  } catch (error) {
    notify(error.message || tr("remote:vnc_ui.connection_settings_failed", {defaultValue:"无法打开连接设置"}), "error");
  }
  notify(tr("remote:vnc_ui.connection_settings_unavailable", {defaultValue:"无法定位主窗口，请先关闭此窗口后从连接列表打开设置"}), "info");
  return false;
}

async function initDetachedVncWindow(profileId) {
  const id = Number(profileId || 0);
  const profile = remoteProfileById(id);
  if (!profile || profile.protocol !== "vnc") {
    notify(tr("remote:vnc_ui.detached_profile_missing", {defaultValue:"VNC 连接不存在"}), "error");
    return false;
  }
  document.documentElement.classList.add("vnc-detached-window");
  document.body.classList.add("vnc-detached-window-body");
  let root = document.getElementById("vncDetachedRoot");
  if (!root) {
    root = document.createElement("main");
    root.id = "vncDetachedRoot";
    root.className = "vnc-detached-root";
    document.body.appendChild(root);
  }
  const key = `detached-vnc-${id}`;
  if (typeof activeTabKey !== "undefined") activeTabKey = key;
  renderEmbeddedVnc(profile, key, null, root, true);
  return true;
}

function vncFullscreenToolbarMode() {
  const value = runtimeSettings?.saved?.vnc_fullscreen_toolbar;
  return ["always", "never", "edge"].includes(value) ? value : "always";
}

function syncVncFullscreenToolbarLabel(session, active) {
  const button = session?.workspace?.querySelector?.("[data-vnc-fullscreen-toggle]");
  if (!button) return;
  const label = tr(active ? "remote:vnc_ui.exit_fullscreen" : "remote:vnc_ui.enter_fullscreen", {defaultValue:active ? "退出内部全屏" : "进入内部全屏"});
  button.title = label;
  button.setAttribute("aria-label", label);
  button.innerHTML = icon(active ? "minimize-2" : "maximize-2");
}

function syncVncFullscreenPresentation() {
  const session = vncSessions.get(vncFullscreenSessionKey);
  const active = document.fullscreenElement === document.documentElement && Boolean(session?.viewport?.isConnected);
  for (const item of vncSessions.values()) {
    const selected = active && item === session;
    item.viewport?.classList.toggle("vnc-fullscreen-active", selected);
    item.workspace?.classList.toggle("vnc-fullscreen-active", selected);
    item.workspace?.classList.toggle("vnc-fullscreen-toolbar-always", selected && vncFullscreenToolbarMode() === "always");
    item.workspace?.classList.toggle("vnc-fullscreen-toolbar-never", selected && vncFullscreenToolbarMode() === "never");
    item.workspace?.classList.toggle("vnc-fullscreen-toolbar-edge", selected && vncFullscreenToolbarMode() === "edge");
    syncVncFullscreenToolbarLabel(item, selected);
  }
  document.documentElement.classList.toggle("vnc-fullscreen-document", active);
  document.documentElement.classList.toggle("vnc-fullscreen-toolbar-edge-visible", false);
  if (!active) {
    if (!document.fullscreenElement || document.fullscreenElement === document.documentElement) vncFullscreenSessionKey = "";
    return;
  }
  requestAnimationFrame(() => {
    try { applyVncDisplayMode(session); } catch {}
    focusEmbeddedVnc(session);
  });
}

const VNC_FULLSCREEN_TOOLBAR_HIDE_DELAY_MS = 500;

function hideVncFullscreenEdgeToolbar(delay=VNC_FULLSCREEN_TOOLBAR_HIDE_DELAY_MS) {
  clearTimeout(window.__termaVncToolbarHideTimer);
  window.__termaVncToolbarHideTimer = setTimeout(() => document.documentElement.classList.remove("vnc-fullscreen-toolbar-edge-visible"), delay);
}

function activeVncFullscreenEdgeSession() {
  const session = vncSessions.get(vncFullscreenSessionKey);
  const fullscreenElement = document.fullscreenElement;
  if (!fullscreenElement || vncFullscreenToolbarMode() !== "edge" || !session?.workspace?.isConnected) return null;
  const containsSession = fullscreenElement === document.documentElement
    || fullscreenElement.contains(session.workspace)
    || session.workspace.contains(fullscreenElement);
  return containsSession && session.workspace.classList.contains("vnc-fullscreen-toolbar-edge") ? session : null;
}

function handleVncFullscreenEdgePointer(event) {
  const session = activeVncFullscreenEdgeSession();
  if (!session) return;
  const target = event.target instanceof Element ? event.target : null;
  const overEdgeZone = Boolean(target?.closest(".vnc-fullscreen-toolbar-edge-zone"));
  if (overEdgeZone || event.clientY <= 1) {
    document.documentElement.classList.add("vnc-fullscreen-toolbar-edge-visible");
    clearTimeout(window.__termaVncToolbarHideTimer);
    return;
  }
  if (document.documentElement.classList.contains("vnc-fullscreen-toolbar-edge-visible")) {
    if (event.clientY <= Math.max(52, session.workspace.querySelector(".vnc-toolbar")?.getBoundingClientRect().bottom || 0)) {
      clearTimeout(window.__termaVncToolbarHideTimer);
    } else hideVncFullscreenEdgeToolbar();
  }
}

if (typeof document !== "undefined") document.addEventListener("fullscreenchange", syncVncFullscreenPresentation);
if (typeof document !== "undefined") {
  document.addEventListener("pointerover", handleVncFullscreenEdgePointer, true);
  document.addEventListener("pointermove", handleVncFullscreenEdgePointer, true);
  document.addEventListener("mouseover", handleVncFullscreenEdgePointer, true);
  document.addEventListener("mousemove", handleVncFullscreenEdgePointer, true);
}

async function toggleVncFullscreen(key) {
  const session = vncSessions.get(key);
  if (!session?.viewport) return;
  if (document.fullscreenElement) {
    await document.exitFullscreen?.();
    return;
  }
  if (!document.documentElement.requestFullscreen) return notify(tr("remote:vnc_ui.fullscreen_unsupported", {defaultValue:"当前环境不支持全屏显示"}), "info");
  // noVNC may render its software cursor as a body-level overlay. Keeping the
  // whole document in the fullscreen tree prevents that cursor from vanishing.
  vncFullscreenSessionKey = key;
  session.viewport.classList.add("vnc-fullscreen-active");
  try {
    await document.documentElement.requestFullscreen();
    syncVncFullscreenPresentation();
  } catch (error) {
    session.viewport.classList.remove("vnc-fullscreen-active");
    vncFullscreenSessionKey = "";
    notify(error.message || tr("remote:vnc_ui.fullscreen_failed", {defaultValue:"无法进入全屏"}), "error");
  }
}
